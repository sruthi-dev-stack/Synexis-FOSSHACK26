<?php
header('Content-Type: application/json');

$host = 'localhost';
$user = 'root';
$pass = ''; // Default XAMPP password is empty
$db = 'veritasdata';

// First, connect to MySQL server without selecting a database
try {
    $pdo_init = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
    $pdo_init->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create the database if it doesn't exist
    $pdo_init->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch(PDOException $e) {
    echo json_encode(['error' => 'Database creation failed: ' . $e->getMessage()]);
    exit;
}

// Now connect to the database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // Create tables if they do not exist
    
    // Datasets table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `datasets` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `session_id` varchar(255) NOT NULL,
        `original_name` varchar(255) NOT NULL,
        `file_path` varchar(500) NOT NULL,
        `upload_timestamp` timestamp DEFAULT CURRENT_TIMESTAMP,
        `row_count` int(11) DEFAULT 0,
        `col_count` int(11) DEFAULT 0,
        `goal` varchar(50) DEFAULT NULL,
        `overall_score` int(11) DEFAULT NULL,
        `status` enum('uploaded', 'analyzed', 'cleaned', 'synthetic') DEFAULT 'uploaded',
        `metadata` longtext DEFAULT NULL,
        PRIMARY KEY (`id`)
    )");

    // Columns table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `columns` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `dataset_id` int(11) NOT NULL,
        `name` varchar(255) NOT NULL,
        `data_type` varchar(50) DEFAULT NULL,
        `missing_count` int(11) DEFAULT 0,
        `trust_score` int(11) DEFAULT NULL,
        `issues` longtext DEFAULT NULL,
        PRIMARY KEY (`id`),
        FOREIGN KEY (`dataset_id`) REFERENCES `datasets`(`id`) ON DELETE CASCADE
    )");

    // Logs for operations
    $pdo->exec("CREATE TABLE IF NOT EXISTS `operations` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `dataset_id` int(11) NOT NULL,
        `operation_type` varchar(100) NOT NULL,
        `details` longtext DEFAULT NULL,
        `timestamp` timestamp DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        FOREIGN KEY (`dataset_id`) REFERENCES `datasets`(`id`) ON DELETE CASCADE
    )");

} catch(PDOException $e) {
    echo json_encode(['error' => 'Database connection or schema creation failed: ' . $e->getMessage()]);
    exit;
}
?>
