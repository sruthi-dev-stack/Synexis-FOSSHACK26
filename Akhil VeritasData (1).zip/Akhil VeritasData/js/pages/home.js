let uploadedData = null;
let selectedGoal = 'ML';
let cleanedRows = null;
let currentDatasetId = null;

const fileInput = document.getElementById('fileInput');
const uploadZone = document.getElementById('uploadZone');

// Goal selection
function selectGoal(el, goal) {
  document.querySelectorAll('.goal-card').forEach(c => {
    c.style.borderColor = 'var(--border)';
    c.style.background = 'var(--bg2)';
  });
  el.style.borderColor = 'var(--teal)';
  el.style.background = 'var(--teal-dim)';
  selectedGoal = goal;
}

if (fileInput) {
    fileInput.addEventListener('change', e => {
      const file = e.target.files[0];
      if (file) handleFile(file);
    });
}
if (uploadZone) {
    uploadZone.addEventListener('dragover', e => {
      e.preventDefault();
      uploadZone.style.borderColor = 'var(--teal)';
      uploadZone.style.background = 'var(--teal-dim)';
    });
    uploadZone.addEventListener('dragleave', () => {
      uploadZone.style.borderColor = 'var(--border2)';
      uploadZone.style.background = 'var(--bg2)';
    });
    uploadZone.addEventListener('drop', e => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    });
}

function handleFile(file) {
  uploadZone.style.borderColor = 'var(--teal)';
  document.getElementById('uploadTitle').textContent = '✓ ' + file.name;
  document.getElementById('uploadSub').textContent = 'Uploading to PHP server... Please wait.';
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append('goal', selectedGoal);

  fetch('api/process.php?action=upload', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      currentDatasetId = data.dataset_id;
      document.getElementById('uploadSub').textContent = `✓ Uploaded to Server — ${data.row_count} rows · ${data.col_count} columns. Click Begin Analysis.`;
      
      // Parse locally to show preview data in UI
      parseFileLocally(file);
    } else {
      alert('Upload failed: ' + data.error);
    }
  })
  .catch(err => {
    console.error(err);
    alert('Upload failed due to network error.');
  });
}

function parseFileLocally(file) {
  const name = file.name.toLowerCase();
  const reader = new FileReader();

  if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
    reader.onload = function(e) {
      try {
        const wb = XLSX.read(new Uint8Array(e.target.result), { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(ws, { defval: '' });
        if (!json.length) return;
        const headers = Object.keys(json[0]);
        const rows = json.map(r => {
          const row = {};
          headers.forEach(h => row[h] = (r[h] !== undefined && r[h] !== null) ? String(r[h]) : '');
          return row;
        });
        uploadedData = { headers, rows };
      } catch(err) { console.error('Local parse Excel error', err); }
    };
    reader.readAsArrayBuffer(file);
  } else if (name.endsWith('.json')) {
    reader.onload = function(e) {
      try {
        let json = JSON.parse(e.target.result);
        if (!Array.isArray(json)) json = Object.values(json).find(v => Array.isArray(v)) || [json];
        const headers = Object.keys(json[0]);
        const rows = json.map(r => {
          const row = {};
          headers.forEach(h => row[h] = r[h] !== undefined ? String(r[h]) : '');
          return row;
        });
        uploadedData = { headers, rows };
      } catch(err) { console.error('Local JSON parse error', err); }
    };
    reader.readAsText(file);
  } else {
    // CSV / TSV
    reader.onload = function(e) {
      const text = e.target.result;
      const sep = name.endsWith('.tsv') ? '\t' : detectSeparator(text);
      uploadedData = parseDelimited(text, sep);
    };
    reader.readAsText(file);
  }
}

function detectSeparator(text) {
  const first = text.split('\n')[0];
  const commas = (first.match(/,/g)||[]).length;
  const semis  = (first.match(/;/g)||[]).length;
  const tabs   = (first.match(/\t/g)||[]).length;
  if (tabs > commas && tabs > semis) return '\t';
  if (semis > commas) return ';';
  return ',';
}

function parseDelimited(text, sep) {
  const lines = text.trim().split('\n').filter(l => l.trim());
  if (lines.length < 2) return null;
  const headers = splitLine(lines[0], sep).map(h => h.trim().replace(/^"|"$/g,''));
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const vals = splitLine(lines[i], sep);
    const row = {};
    headers.forEach((h, j) => row[h] = vals[j] ? vals[j].trim().replace(/^"|"$/g,'') : '');
    rows.push(row);
  }
  return { headers, rows };
}

function splitLine(line, sep) {
  if (sep === '\t') return line.split('\t');
  const result = []; let cur = ''; let inQ = false;
  for (let c of line) {
    if (c === '"') { inQ = !inQ; }
    else if (c === sep && !inQ) { result.push(cur); cur = ''; }
    else cur += c;
  }
  result.push(cur);
  return result;
}

function isMissing(v) {
  return !v || ['','null','na','nan','n/a','none','undefined','-','nil'].includes(v.toString().trim().toLowerCase());
}

function runAnalysis() {
  if (!currentDatasetId) {
    alert('Please upload a file first.');
    return;
  }
  if (!uploadedData) {
    alert('Local file still parsing, please wait a moment.');
    return;
  }

  const btn = document.getElementById('analyseBtn');
  btn.textContent = '◈ Analyzing on PHP Backend...';
  
  fetch('api/process.php?action=analyze&dataset_id=' + currentDatasetId)
    .then(res => res.json())
    .then(data => {
      btn.textContent = '◈ Begin Analysis';
      if(data.success) {
          renderAnalysisResults(data);
      } else {
          alert('Analysis failed: ' + data.error);
      }
    })
    .catch(err => {
      console.error(err);
      alert('Analysis failed due to network error.');
      btn.textContent = '◈ Begin Analysis';
    });
}

function renderAnalysisResults(data) {
  const { headers, rows } = uploadedData;
  const totalRows = rows.length;
  const totalCols = headers.length;

  const score = data.score;
  const scoreAfter = Math.min(100, score + 16);
  
  // Render KPIs
  document.getElementById('scoreNum').textContent = score;
  const sc = score >= 80 ? '#2dc8a0' : score >= 50 ? '#f0a030' : '#e05555';
  document.getElementById('scoreNum').style.color = sc;
  document.getElementById('scoreRing').style.borderColor = sc;
  document.getElementById('scoreLabel').textContent = score >= 80 ? 'Excellent Quality' : score >= 50 ? 'Needs Improvement' : 'Critical — Action Required';
  document.getElementById('scoreLabel').style.color = sc;
  
  document.getElementById('statRows').textContent = totalRows.toLocaleString();
  document.getElementById('statCols').textContent = totalCols;
  document.getElementById('statMissing').textContent = data.total_missing;
  document.getElementById('statDups').textContent = data.total_duplicates;
  document.getElementById('resultsTitle').textContent = 'Analysis Complete — ' + totalRows + ' rows · ' + totalCols + ' columns';

  // Column Table
  const tbody = document.getElementById('colTableBody');
  if(tbody) {
    tbody.innerHTML = '';
    data.columns.forEach(s => {
      const missColor = s.missing > 0 ? '#e05555' : '#2dc8a0';
      const pct = totalRows > 0 ? (s.missing/totalRows*100).toFixed(1) : 0;
      const status = s.missing === 0 ? '<span style="color:#2dc8a0;font-weight:700;">✓ Clean</span>' :
        pct > 30 ? '<span style="color:#e05555;font-weight:700;">⚠ High Risk</span>' :
        '<span style="color:#f0a030;font-weight:700;">△ Review</span>';
      
      const sample = rows[0] ? (rows[0][s.name] || '—') : '—';
      
      tbody.innerHTML += `<tr style="border-bottom:1px solid var(--border);">
        <td style="padding:10px 12px;font-weight:600;color:var(--text)">${s.name}</td>
        <td style="padding:10px 12px;font-family:var(--mono);font-size:11px;color:var(--teal)">${s.type ? s.type.toUpperCase() : 'TEXT'}</td>
        <td style="padding:10px 12px;color:${missColor};font-family:var(--mono)">${s.missing} (${pct}%)</td>
        <td style="padding:10px 12px;color:var(--text2);font-size:11px;">Trust: ${s.trust_score}% | ${sample}</td>
        <td style="padding:10px 12px;">${status}</td>
      </tr>`;
    });
  }

  // Raw Data Table
  renderTable('rawTable', headers, rows.slice(0,10), false);

  // Issues List
  const issuesList = document.getElementById('issuesList');
  if(issuesList) {
    issuesList.innerHTML = '';
    data.issues.forEach(i => {
      const sevColor = i.severity === 'HIGH' ? '#e05555' : '#f0a030';
      const bg = i.severity === 'HIGH' ? '#2d0a0a' : '#2d1f0a';
      issuesList.innerHTML += issueCard(i.severity, sevColor, bg, i.name, 'Multiple', i.detail, 'Apply Auto Clean to fix');
    });
    if (issuesList.innerHTML === '') issuesList.innerHTML = '<div style="color:#2dc8a0;font-weight:600;padding:12px;">✓ No major issues detected. Dataset is clean.</div>';
  }

  // Auto clean process
  fetch('api/process.php?action=clean&dataset_id=' + currentDatasetId)
    .then(res => res.json())
    .then(cleanData => {
       // Cleanup simulation locally
       cleanedRows = rows.map(r => {
         const clean = {...r};
         headers.forEach(h => { if(isMissing(clean[h])) clean[h] = '0/Filled'; });
         return clean;
       });
       renderTable('cleanTable', headers, cleanedRows.slice(0,10), true);
       
       const beforeEl = document.getElementById('beforeStats');
       const afterEl = document.getElementById('afterStats');
       const statRow = (label, val, col) => 
         `<div style="display:flex;justify-content:space-between;font-size:13px;padding:6px 0;border-bottom:1px solid var(--border);">
           <span style="color:var(--text2)">${label}</span>
           <span style="font-family:var(--mono);font-weight:700;color:${col}">${val}</span>
         </div>`;
       
       if(beforeEl && afterEl) {
         beforeEl.innerHTML =
           statRow('Total Rows', cleanData.old_rows, 'var(--text)') +
           statRow('Missing Values', data.total_missing, data.total_missing > 0 ? '#e05555' : '#2dc8a0') +
           statRow('Health Score', cleanData.old_score + ' / 100', cleanData.old_score >= 80 ? '#2dc8a0' : cleanData.old_score >= 50 ? '#f0a030' : '#e05555');
         
         afterEl.innerHTML =
           statRow('Total Rows', cleanData.new_rows, 'var(--text)') +
           statRow('Missing Values', '0', '#2dc8a0') +
           statRow('Health Score', cleanData.new_score + ' / 100', '#2dc8a0');
           
         const improvement = cleanData.new_score - cleanData.old_score;
         document.getElementById('improvePct').textContent = '+' + improvement + ' points';
         setTimeout(() => {
           document.getElementById('improveBar').style.width = Math.min(100, improvement * 2.5) + '%';
         }, 300);
       }
       
       // Download Button
       const dBtn = document.getElementById('downloadBtn');
       if(dBtn) dBtn.onclick = () => downloadCSV(cleanedRows, headers);
       
       document.getElementById('analysisResults').style.display = 'block';
       setTimeout(() => {
         document.getElementById('analysisResults').scrollIntoView({ behavior: 'smooth', block: 'start' });
       }, 100);
    });
}

function issueCard(sev, sevColor, bg, type, col, why, fix) {
  return `<div style="background:${bg};border:1px solid ${sevColor}22;border-left:3px solid ${sevColor};border-radius:10px;padding:16px 18px;">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
      <div style="font-weight:700;color:var(--text);font-size:14px;">${type}</div>
      <div style="display:flex;gap:8px;align-items:center;">
        <span style="font-family:var(--mono);font-size:11px;color:var(--text3)">col: ${col}</span>
        <span style="background:${sevColor}22;color:${sevColor};border:1px solid ${sevColor}44;padding:2px 10px;border-radius:4px;font-size:10px;font-weight:700;">${sev}</span>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px;">
        <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px;">Issue</div>
        <div style="font-size:13px;color:var(--text2);">${why}</div>
      </div>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:10px;">
        <div style="font-size:10px;color:#2dc8a0;text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px;">Fix Applied</div>
        <div style="font-size:13px;color:var(--text2);">${fix}</div>
      </div>
    </div>
  </div>`;
}

function renderTable(id, headers, rows, isClean) {
  const table = document.getElementById(id);
  if(!table) return;
  const headerColor = isClean ? '#2dc8a0' : 'var(--text3)';
  let html = `<thead><tr style="border-bottom:1px solid var(--border);">`;
  headers.forEach(h => {
    html += `<th style="text-align:left;padding:8px 10px;color:${headerColor};font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;white-space:nowrap;">${h}</th>`;
  });
  html += '</tr></thead><tbody>';
  rows.forEach((r, i) => {
    html += `<tr style="border-bottom:1px solid var(--border);background:${i%2===0?'var(--bg)':'var(--bg2)'}">`;
    headers.forEach(h => {
      const v = r[h] || '';
      const isMiss = isMissing(v);
      html += `<td style="padding:8px 10px;font-family:var(--mono);font-size:11px;color:${isMiss ? '#e05555' : 'var(--text2)'};white-space:nowrap;">${isMiss ? 'MISSING' : v}</td>`;
    });
    html += '</tr>';
  });
  html += '</tbody>';
  table.innerHTML = html;
}

function downloadCSV(rows, headers) {
  const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${r[h] || ''}"`).join(','))].join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'veritasdata_clean.csv';
  a.click();
}
