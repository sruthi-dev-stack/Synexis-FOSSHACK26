// Global scroll animations
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.feature-card, .workflow-step, .tech-card, .pipeline-step').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  observer.observe(el);
});

// Custom Cursor
const cursor = document.getElementById('cursor');
const ring = document.getElementById('cursor-ring');
if(cursor && ring) {
    document.addEventListener('mousemove', e => {
      cursor.style.left = e.clientX - 5 + 'px';
      cursor.style.top  = e.clientY - 5 + 'px';
      ring.style.left   = e.clientX - 14 + 'px';
      ring.style.top    = e.clientY - 14 + 'px';
    });
}
